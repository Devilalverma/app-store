var x = 0;
var y = 0;
var op = 0;
onEvent("b1", "click", function( ) {
  if (getText("l1") == 0) {
    setText("l1", "");
  }
  setText("l1", getText("l1") + 1);
});
onEvent("b2", "click", function( ) {
  if (getText("l1") == 0) {
    setText("l1", "");
  }
  setText("l1", getText("l1") + 2);
});
onEvent("b3", "click", function( ) {
  if (getText("l1") == 0) {
    setText("l1", "");
  }
  setText("l1", getText("l1") + 3);
});
onEvent("b4", "click", function( ) {
  if (getText("l1") == 0) {
    setText("l1", "");
  }
  setText("l1", getText("l1") + 4);
});
onEvent("b5", "click", function( ) {
  if (getText("l1") == 0) {
    setText("l1", "");
  }
  setText("l1", getText("l1") + 5);
});
onEvent("b6", "click", function( ) {
  if (getText("l1") == 0) {
    setText("l1", "");
  }
  setText("l1", getText("l1") + 6);
});
onEvent("b7", "click", function( ) {
  if (getText("l1") == 0) {
    setText("l1", "");
  }
  setText("l1", getText("l1") + 7);
});
onEvent("b8", "click", function( ) {
  if (getText("l1") == 0) {
    setText("l1", "");
  }
  setText("l1", getText("l1") + 8);
});
onEvent("b9", "click", function( ) {
  if (getText("l1") == 0) {
    setText("l1", "");
  }
  setText("l1", getText("l1") + 9);
});
onEvent("b0", "click", function( ) {
  if (getText("l1") == 0) {
    setText("l1", "");
  }
  setText("l1", getText("l1") + 0);
});
onEvent("b=", "click", function( ) {
  y = getNumber("l1");
  if (op == 1) {
    x = x / y;
  }
  if (op == 2) {
    x = x * y;
  }
  if (op == 3) {
    x = x - y;
  }
  if (op == 4) {
    x = x + y;
  }
  setText("l1", x);
});
onEvent("bd", "click", function( ) {
  op = 1;
  x = getNumber("l1");
  setText("l1", "");
});
onEvent("ba", "click", function( ) {
  op = 4;
  x = getNumber("l1");
  setText("l1", "");
});
onEvent("bs", "click", function( ) {
  op = 3;
  x = getNumber("l1");
  setText("l1", "");
});
onEvent("bc", "click", function( ) {
  setText("l1", "0");
});
onEvent("bm", "click", function( ) {
  op = 2;
  x = getNumber("l1");
  setText("l1", "");
});
onEvent("button1", "click", function( ) {
  open("https://whjr.co/np3He");
});
