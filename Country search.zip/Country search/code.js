setScreen("screen1");
onEvent("button1", "click", function( ) {
  var user_input = getProperty("text_input1", "text");
  setProperty("text_input1", "text", "");
  var fireletter = user_input.substring(0,1).toUpperCase();
  var countries = getColumn("Countries and Territories", "Country Name");
  var mycountries = [];
  for (var i = 0; i < countries.length; i++) {
    if (countries[i].substring(0, 1)==fireletter) {
      appendItem(mycountries, countries[i]);
    }
  }
  setProperty("text_area1", "text", mycountries.join(" , "));
});
onEvent("image2", "click", function( ) {
  setScreen("screen2");
});
onEvent("image3", "click", function( ) {
  setScreen("screen1");
});
