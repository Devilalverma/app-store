onEvent("White1", "click", function( ) {
  playSound("assets/category_bell/hollow_bell_notification.mp3", false);
});
onEvent("White2", "click", function( ) {
  playSound("assets/category_bell/quiet_bell_notification.mp3", false);
});
onEvent("White3", "click", function( ) {
  playSound("assets/category_bell/vibrant_game_bell_twinkle_positive_touch_1.mp3", false);
});
onEvent("White4", "click", function( ) {
  playSound("assets/category_hits/retro_game_hit_block_4.mp3", false);
});
onEvent("White5", "click", function( ) {
  playSound("assets/category_bell/long_bell_notification.mp3", false);
});
onEvent("White6", "click", function( ) {
  playSound("assets/category_instrumental/chime.mp3", false);
});
onEvent("White7", "click", function( ) {
  playSound("assets/category_instrumental/digital_downscale_1.mp3", false);
});
onEvent("White8", "click", function( ) {
  playSound("assets/category_collect/energy_bar_recharge_4.mp3", false);
});
onEvent("White9", "click", function( ) {
  playSound("assets/category_instrumental/harpe_tripple_pluck.mp3", false);
});
onEvent("White10", "click", function( ) {
  playSound("assets/category_bell/vibrant_game_bell_ding.mp3", false);
});
onEvent("Black1", "click", function( ) {
  playSound("assets/category_bell/bells_win_high.mp3", false);
});
onEvent("Black2", "click", function( ) {
  playSound("assets/category_bell/bells_win.mp3", false);
});
onEvent("Black3", "click", function( ) {
  playSound("assets/category_bell/bells_win_low.mp3", false);
});
onEvent("Black4", "click", function( ) {
  playSound("assets/category_music/8bit_game_over_1.mp3", false);
});
onEvent("Black5", "click", function( ) {
  playSound("assets/category_music/8bit_small_win.mp3", false);
});
onEvent("Black6", "click", function() {
  playSound("assets/category_music/8bit_game_over_2.mp3", false);
});
onEvent("Black7", "click", function( ) {
  playSound("assets/category_music/fun_game_win_musical_4.mp3", false);
});
onEvent("Black8", "click", function( ) {
  playSound("assets/category_music/birthday_kazoo_positive_game_cue_3.mp3", false);
});
