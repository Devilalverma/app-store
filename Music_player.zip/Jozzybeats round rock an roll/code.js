var Y = 30;
onEvent("button1_Previous", "click", function( ) {
  setPosition("label1_Songselecter", 45, Y);
  Y = Y-18;
  setPosition("label1_Songselecter", 45, Y);
  if (Y<13) {
  setPosition("label1_Songselecter", 45, 30);
  Y = 30;
  }
  console.log(Y);
  setPosition("label5_highlight", 185, 318);
  showElement("label5_highlight");
});
onEvent("button2_Stop", "click", function( ) {
  stopSound();
  setPosition("label5_highlight", 105, 320);
  showElement("label5_highlight");
});
onEvent("button3_Next", "click", function( ) {
  Y = Y + 18;
  setPosition("label5_highlight", 255, 320);
  showElement("label5_highlight");
  setPosition("label1_Songselecter", 45, Y);
});
onEvent("button1_Play", "click", function( ) {
  setPosition("label5_highlight", 35, 320);
  showElement("label5_highlight");
  playSound("assets/default.mp3", false);
  if (Y == 30) {
    playSound("assets/01---Bhaag.mp3");
  } else if ((Y == 48)) {
    playSound("assets/02-dil_mera_jumbo---www.downloadming.com.mp3");
  } else if ((Y == 66)) {
    playSound("BTS-(-----)-Dynamite---63rd-GRAMMY-Awards-Show.mp3");
  }
});
