var x = 0;
onEvent("Start", "click", function( ) {
  timedLoop(1000, function() {
    x = x+1;
    setText("label1", x);
  });
});
onEvent("Stop", "click", function( ) {
  stopTimedLoop();
});
onEvent("Reset", "click", function( ) {
  x = 0;
  setText("label1", "0");
});
